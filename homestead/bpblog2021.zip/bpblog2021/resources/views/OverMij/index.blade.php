@extends('main')
@section('title', 'Over Mij')
@section('content')

    <div id="overmij">
    <img src="/images/producer.jpg">
    <div class="title2"> Over Mij
        <div class="txt"> Ik ben Luuk tweede jaars student software developer. <br> Mijn hobby's zijn werken met computers, voetballen en muziek produceren.
        </div>
    </div>
</div>
  
@endsection
