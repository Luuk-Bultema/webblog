<!--met extends kun je een template verlengen, een template die je kunt uitbreiden definieert zijn eigen secties met yield,
hier kun je content in plaatsten-->

@extends('main')
@section('title', 'Dashboard')
@section('content')
    <div id="backgroundhome">
    <div id="title">MUZIEK PRODUCEREN
    </div>
    </div>
@endsection
