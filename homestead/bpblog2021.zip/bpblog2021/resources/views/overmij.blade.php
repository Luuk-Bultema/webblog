@extends('main')
@section('title', 'Home')
@section('content')
@endsection
