<!--met extends kun je een template verlengen, een template die je kunt uitbreiden definieert zijn eigen secties met yield,
hier kun je content in plaatsten-->


<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div id="backgroundhome">
    <div id="title">MUZIEK PRODUCEREN
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/welcome.blade.php ENDPATH**/ ?>