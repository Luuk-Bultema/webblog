
    <ul>
        <li><a href="/posts">Posts</a></li>
        <li><a href="#contact.php">Contact</a></li>
        <li><a href="/OverMij">Over Mij</a></li>
        <li><a class="active" href="/">Home</a></li>
    </ul>


<!--
<a href="/">Home</a>
<a href="/posts">Posts</a>
<hr>
-->


<?php /**PATH /home/vagrant/code/bpblog2021/resources/views/partials/_nav.blade.php ENDPATH**/ ?>