<!--include voegt een partial view toe in je weergave, met extends kun je een template verlengen, een template die je kunt uitbreiden definieert zijn eigen secties met yield,
hier kun je content in plaatsten-->

<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>

<?php /**PATH /home/vagrant/code/bpblog2021/resources/views/main.blade.php ENDPATH**/ ?>