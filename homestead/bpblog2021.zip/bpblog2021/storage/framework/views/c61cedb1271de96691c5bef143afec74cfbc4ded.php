
<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('content'); ?>
<div class="single-posts">
    <h1><?php echo e($post->title); ?></h1>
    <hr/>
    <p><?php echo $post->content; ?></p>
    <hr/>
    <i>Geplaatst door: <?php echo e($post->user_id); ?> op <?php echo e($post->created_at); ?></i>
    <a href="/post/<?php echo e($post->slug); ?> /edit">Wijzig</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/post/single.blade.php ENDPATH**/ ?>