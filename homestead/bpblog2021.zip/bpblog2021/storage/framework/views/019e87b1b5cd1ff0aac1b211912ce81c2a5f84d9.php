<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('content'); ?>
<div class="posts">
    <h1>Dit zijn onze posts!</h1>
    <br/>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/post/<?php echo e($post->slug); ?>"><h2 class="post-title"><?php echo e($post->title); ?></h2></a>
        <p><i>Geplaatst door: <?php echo e($post->user_id); ?> op <?php echo e($post->created_at); ?></i></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br/>
<a href="/posts/create"><u>Maak een nieuwe post!</u></a>
<?php $__env->stopSection(); ?>
 


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/post/index.blade.php ENDPATH**/ ?>