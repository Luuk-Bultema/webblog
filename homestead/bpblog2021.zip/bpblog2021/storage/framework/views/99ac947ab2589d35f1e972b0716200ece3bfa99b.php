

<?php /**PATH /home/vagrant/code/bpblog2021/resources/views/partials/_home.blade.php ENDPATH**/ ?>