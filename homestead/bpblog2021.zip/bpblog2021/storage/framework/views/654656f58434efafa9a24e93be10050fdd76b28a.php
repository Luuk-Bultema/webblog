<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('content'); ?>
<div class="create-post">
    <h1>Maak hier een nieuwe blog post!</h1>
    <hr/>
    <form method="POST" action="/posts">
        <?php echo csrf_field(); ?>
        <label for="txtTitle">Titel:</label><br/>
        <input type="text" name="txtTitle" id="txtTitle"><br/>
        <label for="txtSlug">Slug:</label><br/>
        <input type="text" name="txtSlug" id="txtSlug"><br/>
        <label for="txtContent">Content:</label><br/>
        <textarea name="txtContent" id="txtContent" cols="30" rows="10"></textarea><br/>
        <input type="submit" name="btnSave" value="Opslaan">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/post/create.blade.php ENDPATH**/ ?>