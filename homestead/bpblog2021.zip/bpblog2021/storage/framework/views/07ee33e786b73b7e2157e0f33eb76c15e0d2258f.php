
<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('content'); ?>
<div class="edit-post">
    <h1>Maak hier een nieuwe blog post!</h1>
    <hr/>
    <form method="POST" action="/post/<?php echo e($post-> id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <label for="txtTitle">Titel:</label><br/>
        <input type="text" name="txtTitle" id="txtTitle" value="<?php echo e($post->title); ?>"><br/>
        <label for="txtSlug">Slug:</label><br/>
        <input type="text" name="txtSlug" id="txtSlug" value="<?php echo e($post->slug); ?>"><br/>
        <label for="txtContent">Content:</label><br/>
        <textarea name="txtContent" id="txtContent" cols="30" rows="10"><?php echo e($post->content); ?></textarea><br/>
        <input type="submit" name="btnSave" value="Opslaan">
    </form>
    <br/><br/><br/><br/>
    <button onclick="event.preventDefault(); document.getElementById('delete-post-form').submit();">
        Post verwijderen</button>
    <form id="delete-post-form" action="/post/<?php echo e($post->id); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>;
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/post/edit.blade.php ENDPATH**/ ?>