<h1>Dit wordt mijn post!</h1>
<?php /**PATH /home/vagrant/code/bpblog2021/resources/views/partials/_posts.blade.php ENDPATH**/ ?>