<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <img src="images/producer.jpg">
    </div>


    <div class="title2"> <h1>Over Mij</h1><br>
        <div id="txt"> <p>Ik ben Luuk tweede jaars student software developer. <br> Mijn hobby's zijn werken met computers, voetballen en muziek produceren.</p>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/bpblog2021/resources/views/overmij.blade.php ENDPATH**/ ?>
